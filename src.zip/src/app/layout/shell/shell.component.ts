import { Component, OnInit, inject } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-shell',
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  templateUrl: './shell.component.html',
  styleUrl: './shell.component.scss',
})
export class ShellComponent implements OnInit {
  username = '';
  email = '';
  role = '';
  organizationName = '';
  showdropdown = false;
  userservice = inject(UserService);
  authservice = inject(AuthService);
  router = inject(Router);

  ngOnInit() {
    this.userservice.getUser().subscribe({
      next: (data) => {
        this.username = data.name;
        this.email = data.email;
        this.organizationName = data.organizationName ?? '';
        if (data.role) {
          this.authservice.setRole(data.role);
          this.role = data.role;
        }
      },
      error: () => (this.username = 'account'),
    });
  }

  get isSuperAdmin() { return this.authservice.isSuperAdmin(); }
  get isOrgMember() { return this.authservice.hasAnyRole(['ADMIN', 'MANAGER', 'EMPLOYEE']); }
  get canUseContacts() {return this.authservice.hasAnyRole(['ADMIN', 'MANAGER' , 'EMPLOYEE' , 'USER']); }
  get canReview() { return this.authservice.canReviewRequests(); }
  get isAdmin() { return this.authservice.hasAnyRole(['ADMIN']); }
  get isEmployee(){return this.authservice.hasAnyRole(['EMPLOYEE']);}

  logout() {
    this.authservice.logout();
  }
}
