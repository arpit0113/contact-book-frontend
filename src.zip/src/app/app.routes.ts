import { Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login.component';
import { ShellComponent } from './layout/shell/shell.component';
import { ContactsListComponent } from './pages/contacts-list/contacts-list.component';
import { ContactFormComponent } from './pages/contact-form/contact-form.component';
import { ContactDetailsComponent } from './pages/contact-details/contact-details.component';
import { authGuard } from './guards/auth.guard';
import { homeGuard, roleGuard } from './guards/role.gurad';
import { OauthSuccessComponent } from './pages/oauth-success/oauth-success.component';
import { ProfileComponent } from './pages/profile/profile.component';
import { ContactImportComponent } from './pages/contact-import/contact-import.component';
import { MyRequestsComponent } from './pages/my-requests/my-requests.component';
import { PendingRequestsComponent } from './pages/pending-requests/pending-requests.component';
import { PendingUsersComponent } from './pages/pending-users/pending-users.component';
import { RegisterOrganizationComponent } from './pages/register-organization/register-organization.component';
import { OrgRequestsComponent } from './pages/org-requests/org-requests.component';
import { OrgRequestDetailsComponent } from './pages/org-request-details/org-request-details.component';

const ORG_MEMBERS = ['ADMIN', 'MANAGER', 'EMPLOYEE'] as const;
const CONTACT_USERS =[...ORG_MEMBERS , 'USER'] as const;

export const routes: Routes = [
 
  { path: '', pathMatch: 'full', canActivate: [homeGuard], children: [] },

 
  { path: 'login', component: LoginComponent },
  { path: 'register-organization', component: RegisterOrganizationComponent },
  { path: 'oauth-success', component: OauthSuccessComponent },

 
  {
    path: '',
    component: ShellComponent,
    canActivate: [authGuard],
    children: [
      { path: 'profile', component: ProfileComponent },

      // contacts
      { path: 'contacts', component: ContactsListComponent, canActivate: [roleGuard([...CONTACT_USERS])] },
      { path: 'contacts/add', component: ContactFormComponent, canActivate: [roleGuard([...CONTACT_USERS])] },
      { path: 'contacts/import', component: ContactImportComponent, canActivate: [roleGuard([...CONTACT_USERS])] },
      { path: 'contacts/:id', component: ContactDetailsComponent, canActivate: [roleGuard([...CONTACT_USERS])] },
      { path: 'contacts/:id/edit', component: ContactFormComponent, canActivate: [roleGuard([...CONTACT_USERS])] },
      
      // change requests
      { path: 'my-requests', component: MyRequestsComponent, canActivate: [roleGuard(['EMPLOYEE'])] },
      { path: 'requests/pending', component: PendingRequestsComponent, canActivate: [roleGuard(['ADMIN', 'MANAGER'])] },

      // org admin
      { path: 'team/pending', component: PendingUsersComponent, canActivate: [roleGuard(['ADMIN'])] },

      // super admin
      { path: 'super-admin/organization-requests', component: OrgRequestsComponent, canActivate: [roleGuard(['SUPER_ADMIN'])] },
      {path: 'super-admin/organization-requests/:id', component: OrgRequestDetailsComponent, canActivate : [roleGuard(['SUPER_ADMIN'])]},
    ],
  },

  { path: '**', redirectTo: '' },
];
