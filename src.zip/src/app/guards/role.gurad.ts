import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { catchError, map, of } from 'rxjs';
import { AuthService } from '../services/auth.service';
import { Role } from '../models/user';

/** Where each role lands by default. SUPER_ADMIN has no organization, so no contacts. */
export function homeFor(role: Role | null): string {
  return role === 'SUPER_ADMIN' ? '/super-admin/organization-requests' : '/contacts';
}

/**
 * Allows the route only for the given roles.
 * If the role isn't cached yet (e.g. session created before roles were stored),
 * it is fetched from /api/users/me first.
 */
export function roleGuard(allowedRoles: Role[]): CanActivateFn {
  return () => {
    const auth = inject(AuthService);
    const router = inject(Router);

    const decide = (role: Role | null) =>
      role && allowedRoles.includes(role) ? true : router.createUrlTree([homeFor(role)]);

    const cached = auth.getRole();
    if (cached) return decide(cached);

    return auth.loadProfile().pipe(
      map((user) => decide(user.role)),
      catchError(() => of(router.createUrlTree(['/login'])))
    );
  };
}

/** Used for the empty path: send each role to its own home page. */
export const homeGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (!auth.isLoggedIn()) return router.createUrlTree(['/login']);

  const cached = auth.getRole();
  if (cached) return router.createUrlTree([homeFor(cached)]);

  return auth.loadProfile().pipe(
    map((user) => router.createUrlTree([homeFor(user.role)])),
    catchError(() => of(router.createUrlTree(['/login'])))
  );
};
