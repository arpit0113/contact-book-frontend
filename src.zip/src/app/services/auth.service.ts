import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, map, switchMap, tap } from 'rxjs';
import { environment } from '../../environments/environment';
import {
  AuthResponse, LoginRequest, OrgCreationRequest, OrgCreationResponse,
  OtpVerifyRequest, ResendOtpRequest, SignUpRequest, TokenPair,
} from '../models/auth';
import { Role, User } from '../models/user';

const USER_AUTH_URL = `${environment.API}/api/auth/user`;
const ORG_AUTH_URL = `${environment.API}/api/auth/organizations`;
const ME_URL = `${environment.API}/api/users/me`;

const ACCESS_TOKEN = 'accessToken';
const REFRESH_TOKEN = 'refreshToken';
const ROLE = 'role';

@Injectable({ providedIn: 'root' })
export class AuthService {
  constructor(private http: HttpClient, private router: Router) {}

  /** Logs in, then loads the profile so the role is known before any guard runs. */
  login(dto: LoginRequest): Observable<User> {
    return this.http.post<TokenPair>(`${USER_AUTH_URL}/login`, dto).pipe(
      tap((tokens) => this.storeTokens(tokens)),
      switchMap(() => this.loadProfile())
    );
  }

  /**
   * Register. For LOCAL signups the backend always creates the user as PENDING
   * (waiting for the org admin), so there are usually no tokens in the response.
   */
  signup(dto: SignUpRequest): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${USER_AUTH_URL}/register`, dto).pipe(
      tap((res) => {
        if (res.status === 'ACTIVE' && res.accesstoken && res.refreshToken) {
          this.storeTokens({ accessToken: res.accesstoken, refreshToken: res.refreshToken });
          if (res.user?.role) this.setRole(res.user.role);
        }
      })
    );
  }

  refresh(): Observable<TokenPair> {
    const refreshToken = this.getRefreshToken();
    return this.http
      .post<TokenPair>(`${USER_AUTH_URL}/refresh`, { refreshToken })
      .pipe(tap((res) => this.storeTokens(res)));
  }

  /** GET /api/users/me and cache the role (the JWT itself only carries the email). */
  loadProfile(): Observable<User> {
    return this.http.get<User>(ME_URL).pipe(
      tap((user) => {
        if (user.role) this.setRole(user.role);
      })
    );
  }

  loginWithGoogle() {
    window.location.href = `${environment.API}/oauth2/authorization/google`;
  }

  /** Used by /oauth-success after the backend redirects back with ?token=&refreshToken= */
  completeOAuthLogin(accessToken: string, refreshToken: string | null): Observable<User> {
    this.storeTokens({ accessToken, refreshToken: refreshToken ?? '' });
    return this.loadProfile();
  }

  logout() {
    const refreshToken = this.getRefreshToken();
    if (refreshToken) {
      this.http.post(`${USER_AUTH_URL}/logout`, { refreshToken }).subscribe({
        next: () => {},
        error: () => {},
      });
    }
    this.clearTokens();
    this.router.navigate(['/login']);
  }

  forceLogout() {
    this.clearTokens();
    this.router.navigate(['/login']);
  }

  // ---------- organization onboarding (public endpoints) ----------

  requestOrganization(dto: OrgCreationRequest): Observable<OrgCreationResponse> {
    return this.http.post<OrgCreationResponse>(`${ORG_AUTH_URL}/request`, dto);
  }

  verifyOtp(dto: OtpVerifyRequest): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(`${ORG_AUTH_URL}/verify-otp`, dto);
  }

  resendOtp(dto: ResendOtpRequest): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(`${ORG_AUTH_URL}/resend-otp`, dto);
  }

  // ---------- token / role storage ----------

  private storeTokens(tokens: TokenPair): void {
    localStorage.setItem(ACCESS_TOKEN, tokens.accessToken);
    if (tokens.refreshToken) localStorage.setItem(REFRESH_TOKEN, tokens.refreshToken);
  }

  private clearTokens(): void {
    localStorage.removeItem(ACCESS_TOKEN);
    localStorage.removeItem(REFRESH_TOKEN);
    localStorage.removeItem(ROLE);
  }

  getAccessToken(): string | null { return localStorage.getItem(ACCESS_TOKEN); }
  getRefreshToken(): string | null { return localStorage.getItem(REFRESH_TOKEN); }
  isLoggedIn(): boolean { return !!this.getAccessToken(); }

  setRole(role: Role): void { localStorage.setItem(ROLE, role); }
  getRole(): Role | null { return (localStorage.getItem(ROLE) as Role) ?? null; }
  hasAnyRole(roles: Role[]): boolean {
    const current = this.getRole();
    return current != null && roles.includes(current);
  }
  isSuperAdmin(): boolean { return this.getRole() === 'SUPER_ADMIN'; }
  canReviewRequests(): boolean { return this.hasAnyRole(['MANAGER', 'ADMIN']); }
}
