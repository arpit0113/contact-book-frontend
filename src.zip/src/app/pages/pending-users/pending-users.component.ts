import { CommonModule } from '@angular/common';
import { Component, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { OrgRole, PendingUser } from '../../models/organization';
import { OrganizationService } from '../../services/organization.service';
import { apiError } from '../../utils/api-error';

@Component({
  selector: 'app-pending-users',
  imports: [CommonModule, FormsModule],
  templateUrl: './pending-users.component.html',
  styleUrl: './pending-users.component.scss',
})
export class PendingUsersComponent {
  users = signal<PendingUser[]>([]);
  loading = signal(true);
  error = signal('');
  approvingId = signal<number | null>(null);
  rejectingId = signal<number | null>(null);
  roles = signal<OrgRole[]>([]);
  // tracks the selected role per user id, so each row's dropdown is independent
  selectedRole: Record<number, number> = {};

  constructor(private organizationService: OrganizationService) {}

  ngOnInit() {
    this.load();
  }

  load() {
    this.loading.set(true);
    this.organizationService.getPendingUsers().subscribe({
      next: (data) => {
        this.users.set(data);
        data.forEach((u) => (this.selectedRole[u.userId] = 'EMPLOYEE')); // sensible default
        this.loading.set(false);
      },
      error: (err) => {
        this.error.set(apiError(err, 'failed to load pending users'));
        this.loading.set(false);
      },
    });
    this.organizationService.getRoles().subscribe({
      next: (roles) =>{
        const assignable = roles.filter((r) => r.name !== 'ADMIN');
        this.roles.set(assignable);
        const fallback = assignable.find((r) => r.name === 'EMPLOYEE') ?? assignable[0];
        this.users().forEach((U) => (this.selectedRole[U.userId] = fallback?.id));
      },
      error: (err) => 
        this.error.set(apiError(err, 'failed to load pending users')),
    })
  }

  approve(id: number) {
    const role = this.selectedRole[id];
    this.approvingId.set(id);
    this.organizationService.approveUser(id, { role }).subscribe({
      next: () => {
        this.users.set(this.users().filter((u) => u.userId !== id));
        this.approvingId.set(null);
      },
      error: (err) => {
        this.error.set(apiError(err, 'failed to approve user'));
        this.approvingId.set(null);
      },
    });
  }

  reject(id: number) {
    this.rejectingId.set(id);
    this.organizationService.rejectUser(id).subscribe({
      next : () => {
        this.users.set(this.users().filter((u) => u.userId !== id));
        this.rejectingId.set(null);
      },
      error: (err) =>{
        this.error.set(apiError(err, 'failed to reject user'));
        this.rejectingId.set(null);
      }
    });
  }
}
