// Matches PendingUserDTO { userId, name, email }
export interface PendingUser {
  userId: number;
  name: string;
  email: string;
}
export interface OrgRole{
  id:number;
  name:string;
  systemRole: boolean;
  permissions: string[];
  usercount: number;
}

export interface ApproveUserRequest{
  roleId : number;
}
