export type Role = 'SUPER_ADMIN' | 'ADMIN' | 'EMPLOYEE' | 'MANAGER' |'USER';
export type UserStatus = 'ACTIVE' | 'PENDING';

export interface User {
  id: number;
  name: string;
  email: string;
  organizationName: string | null;
  role: Role | null;
  status: UserStatus;
}
